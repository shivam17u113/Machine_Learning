# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 12:13:49 2019

@author: shivam patil
"""
#@ importing library
import pandas as pd
import numpy as np
from sklearn.preprocessing import PolynomialFeatures
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression


#@ reading file
Dataset= pd.read_csv('Position_Salaries.csv')

#@ dividing into dependat and independat varivbles

x=Dataset.iloc[:,1:2].values
y=Dataset.iloc[:,2].values

#@ appling polynomial regression

reg_p=PolynomialFeatures(degree=2)
  # converting the simple array into polynomial array with respective deree the no of colummns will increase
x_p=reg_p.fit_transform(x)
#reg_p.fit(x_p,y)
""" the only use of the polonomial regression is that we have to convert the given matrix into n dimension 
so that the accuracy will increase the after we apply """

reg_l=LinearRegression()
reg_l.fit(x_p,y)
y_pred_1=reg_l.predict(x_p)

plt.scatter(x,y,color="red")
plt.plot(x,y_pred_1,color="blue")
plt.show()


#@ with more accuracy

reg_p=PolynomialFeatures(degree=3)
  # converting the simple array into polynomial array with respective deree the no of colummns will increase
x_p=reg_p.fit_transform(x)
reg_p.fit(x_p,y)

reg_l=LinearRegression()
reg_l.fit(x_p,y)
y_pred_1=reg_l.predict(x_p)

plt.scatter(x,y,color="red")
plt.plot(x,y_pred_1,color="blue")
plt.show()




reg_p=PolynomialFeatures(degree=5)
  # converting the simple array into polynomial array with respective deree the no of colummns will increase
x_p=reg_p.fit_transform(x)
reg_p.fit(x_p,y)

reg_l=LinearRegression()
reg_l.fit(x_p,y)
y_pred_1=reg_l.predict(x_p)

plt.scatter(x,y,color="red")
plt.plot(x,y_pred_1,color="blue")
plt.show()




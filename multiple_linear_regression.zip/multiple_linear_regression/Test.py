# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 17:09:57 2019

@author: shivam patil
"""

#impoting libraries
import numpy as np
import pandas as pd
from sklearn.preprocessing import Imputer
from sklearn.preprocessing import LabelEncoder,OneHotEncoder
import matplotlib.pyplot as plt
from sklearn.cross_validation import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
import statsmodels.formula.api as sm


dataset1= pd.read_csv("50_Startups.csv")


#@ renamig the columns
dataset1.rename(columns={
                          'R&D Spend':'r_d_spend',
                         'Marketing Spend':'markting_spend',
                         }, 
                 inplace=True)

x=dataset1.iloc[:,:-1].values
y=dataset1.iloc[:,4].values

#@ creating columns for string data type country
label_x=LabelEncoder()
x[:,3]=label_x.fit_transform(x[:,3])
onehotencoder = OneHotEncoder(categorical_features = [3])
x = onehotencoder.fit_transform(x).toarray()

x=x[:,1:]
markting_spend=x[:,4:]
administration=x[:,3:4]
r_d_spend=x[:,2:3]


x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=0)


#@ ploting residual grap
#@ checking the possibility of the independent variables

results = sm.ols(formula='Profit ~ r_d_spend', data=dataset1).fit()
Y_pred = results.predict(dataset1[["r_d_spend"]])
residual = dataset1["Profit"].values-Y_pred
plt.scatter(dataset1[["r_d_spend"]],residual,color="red")

plt.show()

reg=LinearRegression()
reg.fit(x_train,y_train)
y_pred_test=reg.predict(x_test)

y_pred_train=reg.predict(x_train)
#plt.scatter(x_test,y_test, color="red")
plt.plot(x_test,y_test ,color="red")
plt.plot(x_train,y_pred_train,color="blue")
plt.show()
#%%
#@ backword regression
x=np.append(arr=np.ones((50,1)).astype(int), values=x,axis=1)
x_opt=x[:,[0,1,2,3,4,5]]
reg_ols2=sm.OLS(endog=y,exog=x_opt).fit()
reg_ols2.summary()

#@ remong the highest p value




#%%
#@ step1
x_opt=x[:,[0,1,3,4,5]]
reg_ols1=sm.OLS(endog=y,exog=x_opt).fit()
reg_ols1.summary()


#%%
#@ step2
x_opt=x[:,[0,3,4,5]]
reg_ols1=sm.OLS(endog=y,exog=x_opt).fit()
reg_ols1.summary()



#%%
#@ step3
x_opt=x[:,[0,3,5]]
reg_ols1=sm.OLS(endog=y,exog=x_opt).fit()
reg_ols1.summary()




#%%
#@step4
x_opt=x[:,[0,3]]
reg_ols1=sm.OLS(endog=y,exog=x_opt).fit()
reg_ols1.summary()
#@ we get final column





#%%
#@ now we againg divide the testing and traing set for this new x_opt
reg1=LinearRegression()

x_final=x_opt[:,1:]
x_opt_train,x_opt_test,y_opt_train,y_opt_test=train_test_split(x_final,y,test_size=0.2,random_state=0)

reg1.fit(x_opt_train,y_opt_train)
y_pred_test1=reg1.predict(x_opt_test)

y_pred_train1=reg1.predict(x_opt_train)
#plt.scatter(x_test,y_test, color="red")
plt.scatter(x_opt_test,y_opt_test ,color="red")
plt.plot(x_opt_train,y_pred_train1,color="blue")
plt.show()

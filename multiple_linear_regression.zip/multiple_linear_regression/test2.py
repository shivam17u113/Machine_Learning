# -*- coding: utf-8 -*-
"""
Created on Wed Jul 24 16:59:38 2019

@author: shivam patil
"""
#%%
import numpy as np
import pandas as pd
from sklearn.preprocessing import Imputer
from sklearn.preprocessing import LabelEncoder,OneHotEncoder
import matplotlib.pyplot as plt
from sklearn.cross_validation import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
import statsmodels.formula.api as sm


dataset1= pd.read_csv("50_Startups.csv")


#@ renamig the columns
dataset1.rename(columns={
                          'R&D Spend':'r_d_spend',
                         'Marketing Spend':'markting_spend',
                         }, 
                 inplace=True)

x=dataset1.iloc[:,:-1].values
y=dataset1.iloc[:,4].values


label_x=LabelEncoder()
x[:,3]=label_x.fit_transform(x[:,3])
onehotencoder = OneHotEncoder(categorical_features = [3])
x = onehotencoder.fit_transform(x).toarray()

x=x[:,1:]
markting_spend=x[:,4:]
administration=x[:,3:4]
r_d_spend=x[:,2:3]


x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=0)


#@ ploting residual grapg


reg=LinearRegression()
reg.fit(x_train,y_train)
y_pred_test=reg.predict(x_test)

y_pred_train=reg.predict(x_train)
#plt.scatter(x_test,y_test, color="red")
plt.plot(x_test,y_test ,color="red")
plt.plot(x_train,y_pred_train,color="blue")
#plt.show()
#%%
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 11:38:25 2019

@author: shivam patil
"""
#%%
#impoting libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import Imputer
from sklearn.preprocessing import LabelEncoder,OneHotEncoder
import matplotlib.pyplot as plt
from sklearn.cross_validation import train_test_split
from sklearn.preprocessing import StandardScaler

from sklearn.linear_model import LinearRegression

#%%
#@ reading the data 
dataset1= pd.read_csv("Salary_Data.csv")
x=dataset1.iloc[:,:-1].values   # create the dependant variable 
y=dataset1.iloc[:,1].values      # it only select the independent variables




#%%

#@ dividing innto traning and test module

x_train,x_test,y_tain,y_test=train_test_split(x,y,test_size=1/3,random_state=0)



#%%
#@ fitting the simple linear gregresssion

reg=LinearRegression()
reg.fit(x_train,y_tain)# this creates the relation between test set

y_pred=reg.predict(x_test)

#%%
#@ plotting original and predected result
y_pred_train=reg.predict(x_train)
plt.scatter(x_test,y_test, color="red")
plt.plot(x_train,y_pred_train,color="blue")
plt.show()



